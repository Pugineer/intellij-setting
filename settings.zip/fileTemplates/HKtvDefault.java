#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import org.apache.log4j.Logger;

#parse("File Header.java")
public class Default${NAME} implements ${NAME} {

    private static final Logger LOG = Logger.getLogger(Default${NAME}.class);
    
}
