package hktvcore.report.jasper.hktv_overseas_order_delivery_progress

import de.hybris.platform.cronjob.enums.CronJobResult
import de.hybris.platform.cronjob.enums.CronJobStatus
import de.hybris.platform.servicelayer.cronjob.PerformResult
import de.hybris.platform.util.Config
import hk.com.hktv.core.reports.processor.GroovyReportLineProcessor
import hk.com.hktv.core.reports.processor.GroovyReportProcessor
import hk.com.hktv.facades.order.data.HktvCsisReasonResponseData

import java.text.SimpleDateFormat

// TODO update config with correct folder
fileName = "demo_groovy_report"
String filePath = Config.getParameter("HYBRIS_DATA_DIR") + "/demo_groovy_report/"
String sender = Config.getParameter("mail.from")
String senderName = Config.getParameter("mail.smtp.user.displayName")

// TODO, define special data prepare here, if no need, just remove below 
Map<String, String> reasonMap = new HashMap<String, String>()

List<HktvCsisReasonResponseData> refundConsignmentReasonList = hktvCsisService.getRefundConsignmentsReason();

if (refundConsignmentReasonList != null) {
    for (HktvCsisReasonResponseData refundConsignmentReason : refundConsignmentReasonList) {
        reasonMap.put(refundConsignmentReason.getCode(), refundConsignmentReason.getTitle())
    }
}

try {
    // build groovyReportProcessor
    groovyReportProcessor = new GroovyReportProcessor()

    groovyReportProcessor.setSearchQuery(getQuery())
    groovyReportProcessor.setSearchQueryParameter(getQueryParameter()) // delete it if you do not need set query parameter
    groovyReportProcessor.setSearchQueryResultClass(getResultClassList())
    groovyReportProcessor.setFilePath(filePath)
    groovyReportProcessor.setFileName(fileName)
    groovyReportProcessor.setReportHeader(prepareFileHeader())

    // TODO, customize GroovyReportLineProcessor, do not need customize, just use DefaultLineProcessor line below
    // groovyReportLineProcessor = new DefaultReportLineProcessor()
    groovyReportLineProcessor = new GroovyReportLineProcessor() {

        @Override
        List processLine(List row) {
            // should assign variable and add below, make sure line by line!
            pk = row.getAt(0)
            code = row.getAt(1)
            onlinedate = row.getAt(2)
            offlinedate = row.getAt(3)


            dataLine = []
            dataLine.add(pk)
            dataLine.add(code)
            dataLine.add(onlinedate)
            dataLine.add(offlinedate)

            return dataLine
        }
    }

    groovyReportProcessor.processReport(groovyReportLineProcessor)

// TODO delete below if not need send email
    groovyReportProcessor.setToList(["demo_groovy_report.ecom@hktv.com.hk": "demo_groovy_report.ecom"])
    groovyReportProcessor.setSender(sender)
    groovyReportProcessor.setSenderName(senderName)
    groovyReportProcessor.setEmailSubject("[HKTV Mall] demo_groovy_report ")
    groovyReportProcessor.setEmailBody("As attached.")
    groovyReportProcessor.sendEmail()

} catch (Exception e) {
    e.printStackTrace()
    new PerformResult(CronJobResult.FAILURE, CronJobStatus.FINISHED);
}

def prepareFileHeader() {
// TODO update yourself, make sure line by line!
    rptHeaderList = []
    rptHeaderList.add("pk")
    rptHeaderList.add("code")
    rptHeaderList.add("onlinedate")
    rptHeaderList.add("offlinedate")

    return rptHeaderList
}

def getQuery() {
// TODO update yourself, make sure data selection field, table, where case line by line!
// and the '+' sign must in front of the query
    query = (
            " select  "
                    + " {p.pk} as pk, "
                    + " {p.code} as code, "
                    + " {p.onlinedate} as onlinedate, "
                    + " {p.offlinedate} as offlinedate "
                    + " from {  "
                    + " Product as p "
                    + " }  "
                    + " where 1 "
                    + " and {p.onlinedate} is null "
                    + " and {p.offlinedate} > ?today "
    )
    return query
}

def getQueryParameter() { 
    // TODO update yourself, // delete it if you do not need set query parameter
    Calendar today = Calendar.getInstance()
    String strToday = new SimpleDateFormat("yyyyMMdd").format(today.getTime()).toString()
    Map queryParameterMap = new HashMap<String, Object>()
    queryParameterMap.put("today", strToday)
    return queryParameterMap
}

def getResultClassList() {
    resultClassArray = new ArrayList<>()
    resultClassArray.add(String.class)
    resultClassArray.add(String.class)
    resultClassArray.add(String.class)
    resultClassArray.add(String.class)
    // TODO update yourself, make sure line by line!
    return resultClassArray
}